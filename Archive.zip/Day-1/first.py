
print("Good M/E")

# - comment
"""
docstring
"""
#python is indentation
def func1():
    pass
    pass



#int	10, -5
#float	3.14
#str	"hello"
#bool	True
#list	[1, 2, 3]
#tuple	(1, 2, 3)
#set	{1, 2, 3}
#dict	{"k1":"v1","k2":"v2"}
#NoneType	None
#complex	3+5j